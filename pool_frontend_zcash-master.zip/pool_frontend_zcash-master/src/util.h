#include "uint256.h"
#include <algorithm>
#include <limits>

static const int PROTOCOL_VERSION = 70001;
